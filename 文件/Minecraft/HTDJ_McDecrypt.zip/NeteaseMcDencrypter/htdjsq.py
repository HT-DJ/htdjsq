import os
import sys
import subprocess

def show_copyright():
    print("=" * 30)
    print("           HT-DJ        ")
    print("   Minecraft中国版存档解密   ")
    print("=" * 30 + "\n")

def check_python_version():
    """检查Python版本"""
    required_version = (3, 8)
    current_version = sys.version_info[:2]
    if current_version < required_version:
        print(f"Python版本过低（当前 {sys.version.split()[0]}），需要≥3.8")
        print("正在尝试通过pkg更新Python...")
        try:
            subprocess.run(["pkg", "update", "-y"], check=True, capture_output=True)
            subprocess.run(["pkg", "install", "python", "-y"], check=True, capture_output=True)
            print("Python更新完成，请重新运行脚本")
            sys.exit(0)
        except subprocess.CalledProcessError:
            print("更新失败，请手动运行：pkg install python -y")
            sys.exit(1)
    else:
        print(f"✓ Python版本正常（{sys.version.split()[0]}）")

def check_java_installed():
    """检查Java是否安装"""
    try:
        subprocess.run(["java", "-version"], stdout=subprocess.PIPE, 
                      stderr=subprocess.PIPE, text=True, check=True)
        print("✓ Java已安装")
        return True
    except (FileNotFoundError, subprocess.CalledProcessError):
        return False

def install_java():
    """安装Java"""
    print("未检测到Java环境，开始安装OpenJDK...")
    try:
        subprocess.run(["pkg", "update", "-y"], check=True, capture_output=True)
        subprocess.run(["pkg", "install", "openjdk-17", "-y"], check=True, capture_output=True)
        print("✓ Java安装完成")
    except subprocess.CalledProcessError:
        print("Java安装失败，请手动运行：pkg install openjdk-17 -y")
        sys.exit(1)

def find_and_run_jar():
    """在脚本所在目录查找并运行jar文件"""
    # 获取脚本所在目录
    script_dir = os.path.dirname(os.path.abspath(__file__))
    print(f"脚本所在目录: {script_dir}")
    
    # 查找两个必需文件
    jar_file = "NeteaseMcDencrypter.jar"
    batch_file = "启动Jar.bat"
    
    jar_path = os.path.join(script_dir, jar_file)
    batch_path = os.path.join(script_dir, batch_file)
    
    # 检查文件是否存在
    jar_exists = os.path.exists(jar_path)
    batch_exists = os.path.exists(batch_path)
    
    print(f"检查文件: {jar_file} -> {'✓ 存在' if jar_exists else '✗ 不存在'}")
    print(f"检查文件: {batch_file} -> {'✓ 存在' if batch_exists else '✗ 不存在'}")
    
    # 检查是否有文件缺失
    missing_files = []
    if not jar_exists:
        missing_files.append(jar_file)
    if not batch_exists:
        missing_files.append(batch_file)
    
    # 如果有文件缺失，显示详细错误
    if missing_files:
        print(f"\n✗ 错误：以下文件缺失：")
        for file in missing_files:
            print(f"  - {file}")
        
        print(f"\n请确保以下文件都在脚本所在文件夹中：")
        print(f"  1. {jar_file}")
        print(f"  2. {batch_file}")
        print(f"\n脚本位置: {script_dir}")
        sys.exit(1)
    
    print("\n✓ 所需文件存在")
    
    # 读取批处理文件获取启动命令
    java_command = None
    try:
        with open(batch_path, "r", encoding="utf-8") as file:
            content = file.read()
        
        # 查找包含 java -jar 的命令行
        for line in content.splitlines():
            line = line.strip()
            if "java -jar" in line and "NeteaseMcDencrypter.jar" in line:
                java_command = line
                print(f"找到命令: {java_command}")
                break
        
        # 如果没找到，使用默认命令
        if not java_command:
            java_command = "java -jar NeteaseMcDencrypter.jar"
            print(f"使用默认命令: {java_command}")
            
    except Exception as e:
        print(f"读取批处理文件失败：{e}")
        java_command = "java -jar NeteaseMcDencrypter.jar"
        print(f"使用默认命令: {java_command}")
    
    # 运行Java程序
    try:
        # 切换到脚本所在目录
        os.chdir(script_dir)
        print(f"\n执行命令: {java_command}")
        print("正在启动解密程序...")
        
        # 运行命令
        subprocess.run(java_command.split(), check=True)
        
        print("\n✓ 程序运行完成")
        print("\n" + "=" * 30)
        print("   HT-DJ   ")
        print("=" * 30)
        
    except subprocess.CalledProcessError as e:
        print(f"\n✗ 命令运行失败：{e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n✗ 运行时错误：{e}")
        sys.exit(1)

if __name__ == "__main__":
    show_copyright()
    print("===== Termux 环境启动工具 =====")
    
    # 检查环境
    check_python_version()
    # HT-DJ
    if not check_java_installed():
        install_java()
    
    # 查找并运行jar文件
    find_and_run_jar()