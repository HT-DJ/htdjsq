import os #line:1
import sys #line:2
import subprocess #line:3
import platform #line:4
def show_copyright ():#line:7
    print ("="*30 )#line:8
    print ("        浩天DJ制作        ")#line:9
    print ("   未经作者允许禁止外传   ")#line:10
    print ("="*30 +"\n")#line:11
def check_python_version ():#line:13
    ""#line:14
    O000O0OO0O0OOOO00 =(3 ,8 )#line:15
    O0O0OO0O0O0O000OO =sys .version_info [:2 ]#line:16
    if O0O0OO0O0O0O000OO <O000O0OO0O0OOOO00 :#line:17
        print (f"Python版本过低（当前 {sys.version.split()[0]}），需要≥3.8")#line:18
        print ("正在尝试通过pkg更新Python...")#line:19
        try :#line:20
            subprocess .run (["pkg","update","-y"],check =True )#line:22
            subprocess .run (["pkg","install","python","-y"],check =True )#line:23
            print ("Python更新完成，请重新运行脚本")#line:24
            sys .exit (0 )#line:25
        except subprocess .CalledProcessError :#line:26
            print ("更新失败，请手动运行：pkg install python -y")#line:27
            sys .exit (1 )#line:28
    else :#line:29
        print (f"Python版本正常（{sys.version.split()[0]}）")#line:30
def check_java_installed ():#line:32
    ""#line:33
    try :#line:34
        subprocess .run (["java","-version"],stdout =subprocess .PIPE ,stderr =subprocess .PIPE ,text =True )#line:41
        print ("Java已安装")#line:42
        return True #line:43
    except FileNotFoundError :#line:44
        return False #line:45
def install_java ():#line:47
    ""#line:48
    print ("未检测到Java环境，开始安装OpenJDK...")#line:49
    try :#line:50
        subprocess .run (["pkg","update","-y"],check =True )#line:52
        subprocess .run (["pkg","install","openjdk-17","-y"],check =True )#line:54
        print ("Java安装完成")#line:55
    except subprocess .CalledProcessError :#line:56
        print ("Java安装失败，请手动运行：pkg install openjdk-17 -y")#line:57
        sys .exit (1 )#line:58
def run_batch_file ():#line:60
    ""#line:61
    O0OOO0O0O0000000O ="/storage/emulated/0/NeteaseMcDencrypter/启动Jar.bat"#line:63
    if not os .path .exists (O0OOO0O0O0000000O ):#line:66
        print (f"未找到文件：{O0OOO0O0O0000000O}")#line:67
        print ("提示：请确认文件路径正确，或先通过termux-setup-storage授权存储访问")#line:68
        sys .exit (1 )#line:69
    try :#line:72
        with open (O0OOO0O0O0000000O ,"r",encoding ="utf-8")as O0OOO00OOOOO0O00O :#line:73
            OOOOO0O00OOOOOOOO =O0OOO00OOOOO0O00O .read ()#line:74
        O000OOO00OOO00000 =None #line:76
        for O0O0O0OO0O000000O in OOOOO0O00OOOOOOOO .splitlines ():#line:77
            if "java -jar"in O0O0O0OO0O000000O and "NeteaseMcDencrypter.jar"in O0O0O0OO0O000000O :#line:78
                O000OOO00OOO00000 =O0O0O0OO0O000000O .strip ()#line:79
                break #line:80
        if not O000OOO00OOO00000 :#line:81
            O000OOO00OOO00000 ="java -jar NeteaseMcDencrypter.jar"#line:82
    except Exception as O0OOOOOO00000000O :#line:83
        print (f"读取批处理文件失败：{O0OOOOOO00000000O}")#line:84
        O000OOO00OOO00000 ="java -jar NeteaseMcDencrypter.jar"#line:85
    try :#line:88
        os .chdir (os .path .dirname (O0OOO0O0O0000000O ))#line:89
        print (f"切换到目录：{os.getcwd()}")#line:90
        print (f"执行命令：{O000OOO00OOO00000}")#line:91
        subprocess .run (O000OOO00OOO00000 .split (),check =True )#line:92
        print ("程序运行完成")#line:93
        print ("\n"+"="*30 )#line:95
        print ("   未经作者允许禁止外传   ")#line:96
        print ("="*30 )#line:97
    except subprocess .CalledProcessError as O0OOOOOO00000000O :#line:98
        print (f"命令运行失败：{O0OOOOOO00000000O}")#line:99
        sys .exit (1 )#line:100
    except OSError as O0OOOOOO00000000O :#line:101
        print (f"目录切换失败：{O0OOOOOO00000000O}")#line:102
        sys .exit (1 )#line:103
if __name__ =="__main__":#line:105
    show_copyright ()#line:107
    print ("===== Termux 环境启动工具 =====")#line:108
    check_python_version ()#line:110
    if not check_java_installed ():#line:112
        install_java ()#line:113
    run_batch_file ()#line:115
